from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI(title="Қазақстан туралы ақпараттық сайт")

# ---------------------------------------------------------------
# Деректер (сайт пен API бір дереккөзді пайдаланады)
# ---------------------------------------------------------------
INFO = {
    "Ел": "Қазақстан Республикасы",
    "Астанасы": "Астана",
    "Мемлекеттік тілі": "Қазақ тілі",
    "Тәуелсіздік күні": "1991 жылғы 16 желтоқсан",
    "Аумағы": "шамамен 2,7 млн км²",
    "Халқы": "20 миллионнан астам",
    "Валютасы": "теңге",
    "Әкімшілік бөлінісі": "17 облыс, 3 республикалық маңызы бар қала",
}

TIMELINE = [
    {"жыл": "552", "оқиға": "Түрік қағанаты құрылды."},
    {"жыл": "1465", "оқиға": "Керей мен Жәнібек Қазақ хандығының негізін қалады."},
    {"жыл": "XVIII ғ.", "оқиға": "Абылай хан бастаған халық жоңғар шапқыншылығына қарсы күресті."},
    {"жыл": "1837–1847", "оқиға": "Кенесары Қасымұлы бастаған ұлт-азаттық қозғалыс."},
    {"жыл": "1917", "оқиға": "Алаш қайраткерлері Алашорда автономиясын жариялады."},
    {"жыл": "1936", "оқиға": "Қазақ Кеңестік Социалистік Республикасы құрылды."},
    {"жыл": "1986", "оқиға": "Алматыда Желтоқсан көтерілісі болды."},
    {"жыл": "1991", "оқиға": "16 желтоқсанда Қазақстан тәуелсіздігін жариялады."},
    {"жыл": "1997", "оқиға": "Елорда Алматыдан Ақмолаға көшірілді, кейін қала Астана аталды."},
]

QUIZ = [
    {"сұрақ": "Қазақстан тәуелсіздігін қай жылы жариялады?",
     "жауаптар": ["1989", "1991", "1993", "1995"], "дұрыс": 1},
    {"сұрақ": "Қазақ хандығы қай жылы құрылды?",
     "жауаптар": ["1365", "1465", "1565", "1665"], "дұрыс": 1},
    {"сұрақ": "Қазақстанның астанасы қай қала?",
     "жауаптар": ["Астана", "Алматы", "Шымкент", "Қарағанды"], "дұрыс": 0},
    {"сұрақ": "Наурыз мерекесі қай мезгілдің келуін білдіреді?",
     "жауаптар": ["Жаздың", "Күздің", "Қыстың", "Көктемнің"], "дұрыс": 3},
    {"сұрақ": "Қай көлдің бір бөлігі тұщы, екінші бөлігі тұзды?",
     "жауаптар": ["Балқаш", "Байкал", "Зайсан", "Бурабай"], "дұрыс": 0},
]

PAGE = r"""<!DOCTYPE html>
<html lang="kk" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Қазақстан Республикасы – ақпараттық сайт</title>
<meta name="description" content="Қазақстанның тарихы, табиғаты, мәдениеті және мемлекеттік рәміздері туралы заманауи ақпараттық сайт.">
<script>
  // Тақырыпты бет көрінбей тұрып орнату (жыпылықтамау үшін)
  (function () {
    var t = null;
    try { t = localStorage.getItem("theme"); } catch (e) {}
    if (!t) t = window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", t);
  })();
</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Onest:wght@500;700;800&display=swap&subset=cyrillic,cyrillic-ext" rel="stylesheet">
<style>
:root {
  --sky: #00afca;
  --gold: #ffc83d;
  --grass: #6b9140;
  --display: "Onest", "Inter", "Segoe UI", system-ui, sans-serif;
  --body: "Inter", "Segoe UI", system-ui, sans-serif;
  --r-lg: 28px;
  --r-md: 18px;
}
[data-theme="dark"] {
  --bg: #071218;
  --surface: #0d1d26;
  --surface-2: #132f3c;
  --text: #eaf4f8;
  --muted: #94b0bc;
  --line: rgba(255,255,255,.1);
  --glass: rgba(9,24,32,.68);
  --on-sky: #04222b;
}
[data-theme="light"] {
  --bg: #f2f7f9;
  --surface: #ffffff;
  --surface-2: #e3eff4;
  --text: #0b1d25;
  --muted: #476370;
  --line: rgba(11,29,37,.1);
  --glass: rgba(255,255,255,.75);
  --on-sky: #04222b;
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  margin: 0; background: var(--bg); color: var(--text);
  font-family: var(--body); font-size: 17px; line-height: 1.65;
  -webkit-font-smoothing: antialiased;
  transition: background .3s, color .3s;
}
section[id] { scroll-margin-top: 90px; }
a { color: inherit; }
:focus-visible { outline: 3px solid var(--gold); outline-offset: 3px; }
.sr-only { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
.skip { position: absolute; left: -999px; top: 10px; background: var(--gold); color: #1b1400; padding: 8px 14px; border-radius: 8px; z-index: 200; font-weight: 600; }
.skip:focus { left: 10px; }
.wrap { max-width: 1160px; margin: 0 auto; padding: 0 24px; }

/* ================= Навигация ================= */
.nav {
  position: fixed; z-index: 100; top: 14px; left: 50%; transform: translateX(-50%);
  width: min(1100px, calc(100% - 28px));
  display: flex; align-items: center; gap: 10px;
  padding: 8px 10px 8px 22px;
  background: var(--glass); color: var(--text);
  -webkit-backdrop-filter: blur(16px) saturate(1.4); backdrop-filter: blur(16px) saturate(1.4);
  border: 1px solid var(--line); border-radius: 999px;
}
.brand { font-family: var(--display); font-weight: 800; font-size: 18px; text-decoration: none; margin-right: auto; letter-spacing: -.01em; }
.menu { display: flex; gap: 2px; }
.menu a { text-decoration: none; padding: 8px 15px; border-radius: 999px; font-size: 15px; font-weight: 500; color: var(--muted); }
.menu a:hover { color: var(--text); background: var(--surface-2); }
.menu a[aria-current="true"] { color: var(--on-sky); background: var(--gold); }
.icon-btn {
  width: 42px; height: 42px; border-radius: 50%; border: 1px solid var(--line);
  background: var(--surface); color: var(--text); cursor: pointer;
  display: grid; place-items: center; font-size: 18px;
}
.icon-btn:hover { background: var(--surface-2); }
.burger { display: none; }
[data-theme="dark"] .t-moon { display: none; }
[data-theme="light"] .t-sun { display: none; }

/* ================= Hero ================= */
.hero {
  position: relative; overflow: hidden; isolation: isolate;
  min-height: 100svh; display: flex; align-items: center;
  background: #06161d; color: #fff; padding: 130px 0 90px;
}
.hero::before {
  content: ""; position: absolute; inset: -20%; z-index: -1; filter: blur(40px);
  background:
    radial-gradient(38% 42% at 18% 35%, rgba(0,175,202,.55), transparent 70%),
    radial-gradient(30% 34% at 82% 18%, rgba(255,200,61,.28), transparent 70%),
    radial-gradient(40% 36% at 55% 95%, rgba(107,145,64,.4), transparent 70%);
}
.hero::after {
  content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 90px; z-index: -1;
  background: var(--bg);
  clip-path: polygon(0 70%, 10% 52%, 24% 66%, 40% 40%, 56% 62%, 72% 36%, 88% 58%, 100% 44%, 100% 100%, 0 100%);
}
.hero h1 {
  font-family: var(--display); font-weight: 800;
  font-size: clamp(44px, 9.2vw, 118px); line-height: .98; letter-spacing: -.035em;
  margin: 0 0 26px;
}
.hero .lead { font-size: clamp(18px, 2vw, 21px); color: #c4dce5; max-width: 32em; margin: 0 0 36px; }
.hero-text { position: relative; z-index: 2; }
.btn {
  display: inline-flex; align-items: center; gap: 8px;
  font: 600 16px var(--body); text-decoration: none;
  padding: 15px 28px; border-radius: 999px; border: 0; cursor: pointer;
  background: var(--gold); color: #1b1400;
  transition: transform .15s, background .15s;
}
.btn:hover { background: #ffd869; transform: translateY(-2px); }
.btn.ghost { background: rgba(255,255,255,.08); color: #fff; border: 1px solid rgba(255,255,255,.28); margin-left: 8px; }
.btn.ghost:hover { background: rgba(255,255,255,.16); }

.orb-wrap { position: absolute; z-index: 1; right: max(-140px, -9vw); top: 50%; width: min(640px, 82vw); aspect-ratio: 1; margin-top: calc(min(640px, 82vw) / -2); transition: transform .25s ease-out; }
.orb {
  width: 100%; height: 100%; border-radius: 50%;
  background:
    radial-gradient(circle, #fff1c2 0 18%, var(--gold) 18.4% 31%, transparent 31.4%),
    repeating-conic-gradient(var(--gold) 0 3deg, transparent 3deg 11.25deg);
  -webkit-mask: radial-gradient(circle, #000 0 70%, transparent 70.4%);
          mask: radial-gradient(circle, #000 0 70%, transparent 70.4%);
  filter: drop-shadow(0 0 50px rgba(255,200,61,.45));
  opacity: .92;
  animation: sunrise 1.8s cubic-bezier(.2,.7,.2,1) both;
}
@keyframes sunrise { from { transform: translateY(160px) scale(.85); opacity: 0; } to { transform: none; opacity: .92; } }

/* ================= Общие блоки ================= */
section.block { padding: 90px 0 10px; }
h2 { font-family: var(--display); font-weight: 800; font-size: clamp(32px, 5.2vw, 58px); line-height: 1.05; letter-spacing: -.03em; margin: 0 0 18px; }
h3 { font-family: var(--display); font-weight: 700; font-size: 22px; line-height: 1.2; margin: 0 0 8px; letter-spacing: -.01em; }
.prose { max-width: 38em; color: var(--muted); }
.prose p { margin: 0 0 14px; }
.prose strong { color: var(--text); font-weight: 600; }
.section-head { margin-bottom: 36px; }

.bento { display: grid; grid-template-columns: repeat(12, 1fr); gap: 16px; }
.tile {
  background: var(--surface); border: 1px solid var(--line);
  border-radius: var(--r-lg); padding: 28px; position: relative; overflow: hidden;
}
.tile p { margin: 0; color: var(--muted); }
.tile .num { font-family: var(--display); font-weight: 800; letter-spacing: -.04em; line-height: 1; display: block; }
.tile .cap { font-size: 15px; margin-top: 8px; display: block; }
.t-sky { background: linear-gradient(145deg, #00afca, #006f8a); color: #fff; border: 0; }
.t-sky p, .t-sky .cap { color: rgba(255,255,255,.85); }
.t-gold { background: var(--gold); color: #1b1400; border: 0; }
.t-gold p, .t-gold .cap { color: rgba(27,20,0,.78); }
.t-grass { background: linear-gradient(145deg, #5e8238, #3d5a22); color: #fff; border: 0; }
.t-grass p { color: rgba(255,255,255,.85); }
.t-deep { background: var(--surface-2); }
.s3 { grid-column: span 3; } .s4 { grid-column: span 4; } .s5 { grid-column: span 5; }
.s6 { grid-column: span 6; } .s7 { grid-column: span 7; } .s8 { grid-column: span 8; }
.r2 { grid-row: span 2; }

/* Статистика */
.stats { margin-top: -20px; position: relative; z-index: 5; }
.stats .num { font-size: clamp(38px, 5vw, 56px); }
.stats .big .num { font-size: clamp(64px, 11vw, 140px); }
.stats .big { display: flex; flex-direction: column; justify-content: flex-end; min-height: 260px; }

.two { display: grid; grid-template-columns: 1.1fr 1fr; gap: 40px; align-items: start; }
.facts-list { display: grid; gap: 16px; }
.facts-list .tile { padding: 22px 26px; }
.facts-list h3 { font-size: 18px; }

/* ================= Тарих ================= */
.tl-controls { display: flex; gap: 8px; margin-left: auto; }
.head-row { display: flex; align-items: end; gap: 20px; flex-wrap: wrap; }
.tl-track {
  display: flex; gap: 16px; overflow-x: auto; list-style: none; margin: 8px 0 0; padding: 12px 24px 24px;
  scroll-snap-type: x mandatory; scrollbar-width: thin; scrollbar-color: var(--sky) transparent;
}
.tl-card {
  flex: 0 0 min(300px, 78vw); scroll-snap-align: start;
  background: var(--surface); border: 1px solid var(--line); border-radius: var(--r-lg);
  padding: 26px; position: relative; display: flex; flex-direction: column; gap: 10px; min-height: 220px;
}
.tl-card::before { content: ""; width: 14px; height: 14px; border-radius: 50%; background: var(--gold); box-shadow: 0 0 0 5px rgba(255,200,61,.22); }
.tl-year { font-family: var(--display); font-weight: 800; font-size: 34px; letter-spacing: -.03em; line-height: 1; }
.tl-card p { margin: 0; color: var(--muted); }
.tl-card:last-child { background: linear-gradient(145deg, #00afca, #006f8a); color: #fff; border: 0; }
.tl-card:last-child p { color: rgba(255,255,255,.88); }
.tl-card:last-child::before { background: #fff; box-shadow: 0 0 0 5px rgba(255,255,255,.25); }
.tl-wrap { margin: 0 -24px; }

/* ================= Табиғат (қойындылар) ================= */
.tabs { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 18px; }
.tab {
  font: 600 15px var(--body); padding: 11px 20px; border-radius: 999px; cursor: pointer;
  background: var(--surface); color: var(--muted); border: 1px solid var(--line);
}
.tab:hover { color: var(--text); }
.tab[aria-selected="true"] { background: var(--text); color: var(--bg); border-color: var(--text); }
.panel { display: none; grid-template-columns: 1.1fr 1fr; gap: 16px; }
.panel.on { display: grid; }
.panel .tile { min-height: 300px; }
.panel .tile.text { display: flex; flex-direction: column; justify-content: center; gap: 12px; }
.panel .tile.text ul { margin: 6px 0 0; padding-left: 20px; color: var(--muted); }
.panel .tile.text li { margin-bottom: 5px; }
.panel .visual { display: flex; flex-direction: column; justify-content: flex-end; color: #fff; border: 0; }
.panel .visual .num { font-size: clamp(54px, 8vw, 96px); }
.panel .visual .cap { color: rgba(255,255,255,.88); font-size: 16px; }
.v-mount { background: linear-gradient(160deg, #5aa7c7 0%, #1b4e68 55%, #0a2533 100%); }
.v-water { background: linear-gradient(160deg, #00c2d8 0%, #0079a3 60%, #06374c 100%); }
.v-park  { background: linear-gradient(160deg, #8bb24f 0%, #4a6b2a 60%, #1f3412 100%); }
.v-fauna { background: linear-gradient(160deg, #e5a53a 0%, #a8631b 60%, #43260a 100%); }

/* ================= Мәдениет ================= */
.culture .tile h3 { margin-bottom: 10px; }

/* ================= Рәміздер ================= */
.sym { display: flex; flex-direction: column; gap: 18px; }
.sym svg { width: 100%; height: auto; border-radius: var(--r-md); display: block; }
.sym.s4 { padding: 22px; }

/* ================= Викторина ================= */
.quiz { background: var(--surface); border: 1px solid var(--line); border-radius: 36px; padding: clamp(24px, 5vw, 56px); display: grid; grid-template-columns: 1fr 1.2fr; gap: 40px; align-items: start; }
.quiz-side p { color: var(--muted); max-width: 22em; }
.q-progress { height: 6px; border-radius: 99px; background: var(--surface-2); overflow: hidden; margin-bottom: 22px; }
.q-progress i { display: block; height: 100%; width: 0; background: linear-gradient(90deg, var(--sky), var(--gold)); transition: width .35s; }
.q-count { font-size: 14px; color: var(--muted); margin-bottom: 6px; }
.q-text { font-family: var(--display); font-weight: 700; font-size: clamp(22px, 3vw, 30px); line-height: 1.2; margin: 0 0 22px; letter-spacing: -.02em; }
.q-options { display: grid; gap: 10px; }
.q-opt {
  text-align: left; font: 500 17px var(--body); color: var(--text);
  padding: 16px 20px; border-radius: var(--r-md); cursor: pointer;
  background: var(--bg); border: 1.5px solid var(--line);
  transition: border-color .15s, background .15s;
}
.q-opt:hover:not(:disabled) { border-color: var(--sky); }
.q-opt:disabled { cursor: default; }
.q-opt.ok { border-color: #2fbf71; background: rgba(47,191,113,.16); }
.q-opt.bad { border-color: #ef5a5a; background: rgba(239,90,90,.14); }
.q-next { margin-top: 20px; }
.q-result .score { font-family: var(--display); font-weight: 800; font-size: clamp(56px, 9vw, 96px); letter-spacing: -.04em; line-height: 1; }
.q-result p { color: var(--muted); }

/* ================= Footer ================= */
footer { margin-top: 110px; background: #06161d; color: #a9c4cf; padding: 56px 0 40px; }
.foot { display: flex; flex-wrap: wrap; gap: 28px; justify-content: space-between; align-items: flex-start; }
.foot strong { font-family: var(--display); font-size: 22px; color: #fff; letter-spacing: -.01em; }
.foot a { color: var(--gold); text-decoration: none; }
.foot a:hover { text-decoration: underline; }
.foot .links { display: flex; flex-wrap: wrap; gap: 18px; }

/* ================= Адаптив ================= */
@media (max-width: 900px) {
  .menu { position: absolute; top: calc(100% + 10px); left: 0; right: 0; flex-direction: column;
    background: var(--surface); border: 1px solid var(--line); border-radius: 24px; padding: 10px; display: none; }
  .nav.open .menu { display: flex; }
  .menu a { padding: 14px 18px; font-size: 17px; }
  .burger { display: grid; }
  .s3, .s4, .s5, .s6, .s7, .s8 { grid-column: span 6; }
  .stats .big { grid-column: span 12; }
  .two, .panel, .quiz { grid-template-columns: 1fr; }
  .sym.s4 { grid-column: span 12; }
}
@media (max-width: 560px) {
  .s3, .s4, .s5, .s6, .s7, .s8 { grid-column: span 12; }
  .btn.ghost { margin: 10px 0 0; }
  .tile { padding: 22px; }
}
@media (prefers-reduced-motion: reduce) {
  html { scroll-behavior: auto; }
  .orb { animation: none; }
  * { transition: none !important; }
}
</style>
</head>
<body>
<a class="skip" href="#content">Негізгі мазмұнға өту</a>

<header class="nav" id="nav">
  <a class="brand" href="#top">Қазақстан</a>
  <nav class="menu" id="menu" aria-label="Негізгі мәзір">
    <a href="#about">Ел туралы</a>
    <a href="#history">Тарихы</a>
    <a href="#nature">Табиғаты</a>
    <a href="#culture">Мәдениеті</a>
    <a href="#symbols">Рәміздері</a>
    <a href="#quiz">Викторина</a>
  </nav>
  <button class="icon-btn" id="themeBtn" aria-label="Түнгі/күндізгі режимді ауыстыру" title="Тақырыпты ауыстыру">
    <span class="t-sun" aria-hidden="true">☀</span><span class="t-moon" aria-hidden="true">☾</span>
  </button>
  <button class="icon-btn burger" id="burger" aria-label="Мәзірді ашу" aria-expanded="false">☰</button>
</header>

<section class="hero" id="top">
  <div class="orb-wrap" id="orbWrap" aria-hidden="true"><div class="orb"></div></div>
  <div class="wrap">
    <div class="hero-text">
      <h1>Қазақстан<br>Республикасы</h1>
      <p class="lead">Ұланғайыр дала, биік таулар мен ежелгі тарих тоғысқан ел. Тарихы, табиғаты, мәдениеті және рәміздері – бір бетте.</p>
      <a class="btn" href="#about">Танысуды бастау</a>
      <a class="btn ghost" href="#quiz">Білімді тексеру</a>
    </div>
  </div>
</section>

<main id="content">

  <!-- ===== Қысқаша деректер ===== -->
  <section class="stats" aria-label="Қазақстан сандармен">
    <div class="wrap">
      <div class="bento">
        <div class="tile t-sky big s6 r2">
          <span class="num"><span data-count="2.7" data-dec="1">2,7</span></span>
          <span class="cap">миллион шаршы километр – аумағы бойынша әлемде тоғызыншы ел</span>
        </div>
        <div class="tile s6">
          <span class="num"><span data-count="20">20</span>+</span>
          <span class="cap">миллион халық, 130-дан астам ұлт өкілі</span>
        </div>
        <div class="tile s3">
          <span class="num" data-count="17">17</span>
          <span class="cap">облыс</span>
        </div>
        <div class="tile t-gold s3">
          <span class="num" data-count="1991" data-plain="1">1991</span>
          <span class="cap">тәуелсіздік жылы</span>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== Ел туралы ===== -->
  <section class="block" id="about">
    <div class="wrap">
      <div class="section-head">
        <h2>Қазақстан туралы</h2>
      </div>
      <div class="two">
        <div class="prose">
          <p>Қазақстан – Еуразия құрлығының жүрегінде орналасқан тәуелсіз, егемен мемлекет. Аумағы жағынан ол әлемдегі <strong>тоғызыншы</strong>, ал теңізге шығуы жоқ елдердің ішіндегі <strong>ең үлкен</strong> ел.</p>
          <p>Солтүстігі мен батысында Ресеймен, шығысында Қытаймен, оңтүстігінде Қырғызстан, Өзбекстан және Түрікменстанмен шектеседі. Батыс шекарасында Каспий теңізі жатыр.</p>
          <p>Мемлекеттік тілі – қазақ тілі, астанасы – <strong>Астана</strong>. Ел 17 облыс пен республикалық маңызы бар үш қалаға – Астана, Алматы және Шымкентке бөлінеді.</p>
          <p>Қазақстан мұнай, газ, уран, түсті және қара металдарға бай. Уран өндіру бойынша ел әлемде алдыңғы орындардың бірінде тұр. Астық шаруашылығы мен мал өсіру де маңызды салалар болып қала береді.</p>
        </div>
        <div class="facts-list">
          <div class="tile t-deep">
            <h3>Байқоңыр</h3>
            <p>Әлемдегі ең ірі әрі ең көне ғарыш айлақтарының бірі. 1961 жылы Юрий Гагарин осы жерден ғарышқа ұшқан.</p>
          </div>
          <div class="tile">
            <h3>Елорда</h3>
            <p>Астана 1997 жылдан бері елорда, ал 1998 жылы халықаралық деңгейде таныстырылды. Бұған дейін қала Ақмола деп аталған.</p>
          </div>
          <div class="tile">
            <h3>ЮНЕСКО мұрасы</h3>
            <p>Түркістандағы Қожа Ахмет Ясауи кесенесі сияқты нысандар Бүкіләлемдік мұра тізіміне енген.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== Тарих ===== -->
  <section class="block" id="history">
    <div class="wrap">
      <div class="head-row section-head">
        <div>
          <h2>Тарихы</h2>
          <div class="prose">
            <p>Сақтар, үйсіндер, қаңлылар мен ғұндардан бастап тәуелсіздікке дейін – қазақ даласының ұзақ жолы. Ұлы Жібек жолы осы өңір арқылы Шығыс пен Батысты байланыстырды.</p>
          </div>
        </div>
        <div class="tl-controls">
          <button class="icon-btn" id="tlPrev" aria-label="Алдыңғы оқиғалар">←</button>
          <button class="icon-btn" id="tlNext" aria-label="Келесі оқиғалар">→</button>
        </div>
      </div>
    </div>
    <div class="wrap">
      <div class="tl-wrap">
        <ol class="tl-track" id="tlTrack" aria-label="Тарихи оқиғалар хронологиясы" tabindex="0">
          %%TIMELINE%%
        </ol>
      </div>
    </div>
  </section>

  <!-- ===== Табиғат ===== -->
  <section class="block" id="nature">
    <div class="wrap">
      <div class="section-head">
        <h2>Табиғаты</h2>
        <div class="prose">
          <p>Жазықтардың шексіз даласынан мұзарттар жататын шыңдарға дейін: Қазақстанда шөл, шөлейт, дала, орманды дала және тау белдеулері бар.</p>
        </div>
      </div>

      <div class="tabs" role="tablist" aria-label="Табиғат тақырыптары">
        <button class="tab" role="tab" id="tab-mount" aria-controls="p-mount" aria-selected="true">Таулар</button>
        <button class="tab" role="tab" id="tab-water" aria-controls="p-water" aria-selected="false" tabindex="-1">Су көздері</button>
        <button class="tab" role="tab" id="tab-park" aria-controls="p-park" aria-selected="false" tabindex="-1">Саябақтар</button>
        <button class="tab" role="tab" id="tab-fauna" aria-controls="p-fauna" aria-selected="false" tabindex="-1">Жануарлар</button>
      </div>

      <div class="panel on" id="p-mount" role="tabpanel" aria-labelledby="tab-mount">
        <div class="tile text">
          <h3>Тянь-Шань, Жетісу Алатауы, Алтай</h3>
          <p>Оңтүстік-шығыста Тянь-Шань мен Жетісу (Жоңғар) Алатауы, шығыста Алтай тауы орналасқан. Бұл өңірлерде мұздықтар, альпі шалғындары және қылқан жапырақты ормандар кездеседі.</p>
          <ul><li>Алматы маңындағы Іле Алатауы</li><li>Алтайдағы Берел және Катонқарағай алқабы</li></ul>
        </div>
        <div class="tile visual v-mount"><span class="num">≈7 000 м</span><span class="cap">Хан Тәңірі – елдегі ең биік шыңдардың бірі</span></div>
      </div>

      <div class="panel" id="p-water" role="tabpanel" aria-labelledby="tab-water">
        <div class="tile text">
          <h3>Көлдер, өзендер, теңіздер</h3>
          <p>Балқаш көлінің бір бөлігі тұщы, екінші бөлігі тұзды. Ертіс, Есіл, Сырдария және Жайық – ірі өзендер. Каспий мен Арал теңіздері де елдің су қорының маңызды бөлігі.</p>
          <ul><li>Балқаш пен Зайсан – ірі көлдер</li><li>Солтүстік Арал теңізі қалпына келтіріліп жатыр</li></ul>
        </div>
        <div class="tile visual v-water"><span class="num">Балқаш</span><span class="cap">бір көлде тұщы да, тұзды да су</span></div>
      </div>

      <div class="panel" id="p-park" role="tabpanel" aria-labelledby="tab-park">
        <div class="tile text">
          <h3>Табиғат ескерткіштері</h3>
          <p>Шарын шатқалы, Бурабай мен Баянауыл ұлттық саябақтары, Алтын-Емел өңірі саяхатшыларды жыл сайын өзіне тартады. Әрқайсысының өз ландшафты, өз аңызы бар.</p>
          <ul><li>Шарын – «Аңғарлар аңғары» атты қызыл құз</li><li>Бурабай – «Қазақстанның Швейцариясы»</li></ul>
        </div>
        <div class="tile visual v-park"><span class="num">Шарын</span><span class="cap">миллиондаған жылда қалыптасқан шатқал</span></div>
      </div>

      <div class="panel" id="p-fauna" role="tabpanel" aria-labelledby="tab-fauna">
        <div class="tile text">
          <h3>Жануарлар дүниесі</h3>
          <p>Қар барысы, архар, бүркіт, дала қыраны және ақбөкен (киік) – еліміздің танымал жануарлары. Ақбөкен популяциясын сақтау үшін арнайы шаралар қабылданады.</p>
          <ul><li>Қар барысы – таудың сирек мекендеушісі</li><li>Ақбөкен – дала антилопасы</li></ul>
        </div>
        <div class="tile visual v-fauna"><span class="num">Ақбөкен</span><span class="cap">даланың ең танымал тұяқтыларының бірі</span></div>
      </div>
    </div>
  </section>

  <!-- ===== Мәдениет ===== -->
  <section class="block culture" id="culture">
    <div class="wrap">
      <div class="section-head">
        <h2>Мәдениеті мен дәстүрі</h2>
        <div class="prose">
          <p>Қазақ мәдениеті көшпелі өмір салтымен тығыз байланысты. Қонақжайлылық, үлкенді сыйлау және ауызбіршілік – халықтың басты құндылықтары.</p>
        </div>
      </div>
      <div class="bento">
        <div class="tile t-gold s5">
          <h3>Наурыз мерекесі</h3>
          <p>Көктемнің келуін, табиғаттың жаңаруын білдіретін ең көне мереке. Қазақстанда 21–23 наурыз аралығында аталып өтеді: наурыз көже дайындалады, ұлттық ойындар ұйымдастырылады.</p>
        </div>
        <div class="tile s7">
          <h3>Домбыра мен күй</h3>
          <p>Домбыра – екі ішекті ұлттық аспап. Құрманғазы, Дәулеткерей, Тәттімбет сияқты күйшілердің шығармалары қазақ музыкасының алтын қорын құрайды. Ән, жыр және айтыс өнері де рухани мұраның маңызды бөлігі.</p>
        </div>
        <div class="tile s4">
          <h3>Ұлттық тағамдар</h3>
          <p>Бешбармақ – ең танымал тағам. Қуырдақ, сорпа, бауырсақ, қымыз, шұбат және айран да дастарханның құрметті бөлігі.</p>
        </div>
        <div class="tile t-grass s4">
          <h3>Киіз үй</h3>
          <p>Көшпенділердің ыңғайлы әрі берік баспанасы. Төбесіндегі шаңырақ Қазақстан елтаңбасында да бейнеленген. Киіз басу, кілем тоқу, зергерлік – ғасырлар бойы дамыған қолөнер.</p>
        </div>
        <div class="tile t-deep s4">
          <h3>Ұлы тұлғалар</h3>
          <p>Әл-Фараби – «Екінші ұстаз» атанған ғұлама. Абай – қазақ жазба әдебиетінің негізін қалаушы. Мұхтар Әуезов – «Абай жолы» эпопеясының авторы.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== Рәміздер ===== -->
  <section class="block" id="symbols">
    <div class="wrap">
      <div class="section-head">
        <h2>Мемлекеттік рәміздер</h2>
        <div class="prose"><p>Рәміздер – ел бірлігі мен егемендігінің белгісі. Әрқайсысында халықтың тарихы мен арманы көрініс тапқан.</p></div>
      </div>
      <div class="bento">
        <div class="tile sym s4">
          <svg viewBox="0 0 300 160" role="img" aria-label="Қазақстан туының сызбасы">
            <rect width="300" height="160" fill="#00afca"/>
            <g stroke="#ffc83d" stroke-width="3" stroke-linecap="round">
              <line x1="150" y1="22" x2="150" y2="34"/><line x1="150" y1="86" x2="150" y2="98"/>
              <line x1="118" y1="54" x2="130" y2="54"/><line x1="170" y1="54" x2="182" y2="54"/>
              <line x1="127" y1="31" x2="135" y2="39"/><line x1="165" y1="69" x2="173" y2="77"/>
              <line x1="173" y1="31" x2="165" y2="39"/><line x1="135" y1="69" x2="127" y2="77"/>
            </g>
            <circle cx="150" cy="60" r="16" fill="#ffc83d"/>
            <path d="M92 118 C118 96 138 106 150 112 C162 106 182 96 208 118 C186 110 166 114 150 126 C134 114 114 110 92 118Z" fill="#ffc83d"/>
            <rect x="10" y="10" width="16" height="140" fill="none" stroke="#ffc83d" stroke-width="2"/>
            <g fill="#ffc83d"><path d="M18 24 l5 8 -5 8 -5 -8z"/><path d="M18 52 l5 8 -5 8 -5 -8z"/><path d="M18 80 l5 8 -5 8 -5 -8z"/><path d="M18 108 l5 8 -5 8 -5 -8z"/></g>
          </svg>
          <div>
            <h3>Ту</h3>
            <p>Аспан түстес кенепте шуақты күн мен оның астында қалықтаған қыран бейнеленген. Туды 1992 жылы суретші Шәкен Ниязбеков жасаған. Ту жағасында ұлттық оюмен өрнектелген жолақ бар.</p>
          </div>
        </div>
        <div class="tile sym s4">
          <svg viewBox="0 0 300 160" role="img" aria-label="Қазақстан елтаңбасының сызбасы">
            <rect width="300" height="160" fill="#0d3a4a"/>
            <circle cx="150" cy="82" r="62" fill="#00afca" stroke="#ffc83d" stroke-width="5"/>
            <g stroke="#ffc83d" stroke-width="3" stroke-linecap="round">
              <line x1="150" y1="82" x2="150" y2="34"/><line x1="150" y1="82" x2="150" y2="130"/>
              <line x1="150" y1="82" x2="102" y2="82"/><line x1="150" y1="82" x2="198" y2="82"/>
              <line x1="150" y1="82" x2="116" y2="48"/><line x1="150" y1="82" x2="184" y2="116"/>
              <line x1="150" y1="82" x2="184" y2="48"/><line x1="150" y1="82" x2="116" y2="116"/>
            </g>
            <circle cx="150" cy="82" r="22" fill="none" stroke="#ffc83d" stroke-width="3"/>
            <polygon points="150,8 154,18 165,18 156,25 160,36 150,29 140,36 144,25 135,18 146,18" fill="#ffc83d"/>
          </svg>
          <div>
            <h3>Елтаңба</h3>
            <p>Негізінде шаңырақ тұр. Оны екі жағынан қанатты тұлпарлар қолдап тұр, ал жоғарыда жұлдыз орналасқан. Елтаңбаны Жандарбек Мәлібеков пен Шота Уәлиханов жасаған.</p>
          </div>
        </div>
        <div class="tile sym s4">
          <svg viewBox="0 0 300 160" role="img" aria-label="Әнұран – дыбыс толқындарының бейнесі">
            <rect width="300" height="160" fill="#1c3a1a"/>
            <g fill="#6b9140">
              <rect x="30" y="64" width="10" height="32" rx="5"/><rect x="52" y="48" width="10" height="64" rx="5"/>
              <rect x="74" y="30" width="10" height="100" rx="5"/><rect x="96" y="54" width="10" height="52" rx="5"/>
              <rect x="118" y="38" width="10" height="84" rx="5"/><rect x="140" y="20" width="10" height="120" rx="5" fill="#ffc83d"/>
              <rect x="162" y="42" width="10" height="76" rx="5"/><rect x="184" y="58" width="10" height="44" rx="5"/>
              <rect x="206" y="34" width="10" height="92" rx="5"/><rect x="228" y="52" width="10" height="56" rx="5"/>
              <rect x="250" y="68" width="10" height="24" rx="5"/>
            </g>
          </svg>
          <div>
            <h3>Әнұран</h3>
            <p>«Менің Қазақстаным» әні 2006 жылдан бері мемлекеттік әнұран болып табылады. Әнұранның әні Шәмші Қалдаяковқа тиесілі.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== Викторина ===== -->
  <section class="block" id="quiz">
    <div class="wrap">
      <div class="quiz">
        <div class="quiz-side">
          <h2>Білімді тексер</h2>
          <p>Бес қысқа сұрақ. Сайттағы мәліметті қаншалықты есте сақтағаныңды біл.</p>
        </div>
        <div id="quizBox" aria-live="polite">
          <p class="q-count">Сұрақтар жүктелуде…</p>
        </div>
      </div>
    </div>
  </section>

</main>

<footer>
  <div class="wrap foot">
    <div>
      <strong>Қазақстан Республикасы</strong><br>
      Ақпараттық веб-сайт · FastAPI арқылы жасалған<br>
      © 2026 Қазақстан туралы ақпараттық сайт
    </div>
    <div class="links">
      <a href="/api/info">/api/info</a>
      <a href="/api/tarih">/api/tarih</a>
      <a href="/api/quiz">/api/quiz</a>
      <a href="/docs">API құжаттамасы</a>
    </div>
  </div>
</footer>

<script>
(function () {
  var doc = document.documentElement;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---- Тақырып ауыстыру ---- */
  document.getElementById("themeBtn").addEventListener("click", function () {
    var next = doc.getAttribute("data-theme") === "dark" ? "light" : "dark";
    doc.setAttribute("data-theme", next);
    try { localStorage.setItem("theme", next); } catch (e) {}
  });

  /* ---- Мобильді мәзір ---- */
  var nav = document.getElementById("nav");
  var burger = document.getElementById("burger");
  burger.addEventListener("click", function () {
    var open = nav.classList.toggle("open");
    burger.setAttribute("aria-expanded", open);
    burger.textContent = open ? "✕" : "☰";
  });
  document.querySelectorAll("#menu a").forEach(function (a) {
    a.addEventListener("click", function () {
      nav.classList.remove("open");
      burger.setAttribute("aria-expanded", "false");
      burger.textContent = "☰";
    });
  });

  /* ---- Белсенді мәзір сілтемесі ---- */
  var links = {};
  document.querySelectorAll("#menu a").forEach(function (a) { links[a.getAttribute("href").slice(1)] = a; });
  var secObs = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting && links[e.target.id]) {
        Object.keys(links).forEach(function (k) { links[k].removeAttribute("aria-current"); });
        links[e.target.id].setAttribute("aria-current", "true");
      }
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  Object.keys(links).forEach(function (id) { var el = document.getElementById(id); if (el) secObs.observe(el); });

  /* ---- Күн орбы: тышқан параллаксы ---- */
  var orbWrap = document.getElementById("orbWrap");
  if (!reduce && window.matchMedia("(pointer: fine)").matches) {
    window.addEventListener("pointermove", function (e) {
      var x = (e.clientX / window.innerWidth - .5) * -30;
      var y = (e.clientY / window.innerHeight - .5) * -30;
      orbWrap.style.transform = "translate(" + x + "px," + y + "px)";
    });
  }

  /* ---- Сандардың өсуі ---- */
  function fmt(v, dec, plain) {
    var s = dec ? v.toFixed(dec).replace(".", ",") : String(Math.round(v));
    return s;
  }
  var cntObs = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      cntObs.unobserve(e.target);
      var el = e.target, end = parseFloat(el.dataset.count), dec = parseInt(el.dataset.dec || "0", 10);
      if (reduce) { el.textContent = fmt(end, dec); return; }
      var start = performance.now(), dur = 1400;
      (function tick(now) {
        var p = Math.min((now - start) / dur, 1);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = fmt(end * eased, dec);
        if (p < 1) requestAnimationFrame(tick);
      })(start);
    });
  }, { threshold: .6 });
  document.querySelectorAll("[data-count]").forEach(function (el) { cntObs.observe(el); });

  /* ---- Тарих лентасы ---- */
  var track = document.getElementById("tlTrack");
  function scrollTl(dir) { track.scrollBy({ left: dir * 316, behavior: reduce ? "auto" : "smooth" }); }
  document.getElementById("tlPrev").addEventListener("click", function () { scrollTl(-1); });
  document.getElementById("tlNext").addEventListener("click", function () { scrollTl(1); });

  /* ---- Қойындылар ---- */
  var tabs = Array.prototype.slice.call(document.querySelectorAll(".tab"));
  function selectTab(tab) {
    tabs.forEach(function (t) {
      var on = t === tab;
      t.setAttribute("aria-selected", on);
      t.tabIndex = on ? 0 : -1;
      document.getElementById(t.getAttribute("aria-controls")).classList.toggle("on", on);
    });
  }
  tabs.forEach(function (t, i) {
    t.addEventListener("click", function () { selectTab(t); });
    t.addEventListener("keydown", function (e) {
      var n = null;
      if (e.key === "ArrowRight") n = tabs[(i + 1) % tabs.length];
      if (e.key === "ArrowLeft") n = tabs[(i - 1 + tabs.length) % tabs.length];
      if (n) { n.focus(); selectTab(n); e.preventDefault(); }
    });
  });

  /* ---- Викторина (сұрақтар /api/quiz арқылы келеді) ---- */
  var box = document.getElementById("quizBox");
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }
  fetch("/api/quiz").then(function (r) { return r.json(); }).then(startQuiz).catch(function () {
    box.textContent = "Сұрақтарды жүктеу мүмкін болмады. Серверді тексеріңіз.";
  });

  function startQuiz(data) {
    var i = 0, score = 0;

    function showQuestion() {
      var q = data[i];
      box.innerHTML = "";
      var bar = el("div", "q-progress"); var fill = el("i"); fill.style.width = (i / data.length * 100) + "%"; bar.appendChild(fill);
      box.appendChild(bar);
      box.appendChild(el("div", "q-count", "Сұрақ " + (i + 1) + " / " + data.length));
      box.appendChild(el("p", "q-text", q["сұрақ"]));
      var list = el("div", "q-options");
      var next = el("button", "btn q-next", i === data.length - 1 ? "Нәтижені көру" : "Келесі сұрақ");
      next.hidden = true;
      q["жауаптар"].forEach(function (text, idx) {
        var b = el("button", "q-opt", text);
        b.addEventListener("click", function () {
          var buttons = list.querySelectorAll(".q-opt");
          buttons.forEach(function (x) { x.disabled = true; });
          if (idx === q["дұрыс"]) { b.classList.add("ok"); score++; }
          else { b.classList.add("bad"); buttons[q["дұрыс"]].classList.add("ok"); }
          next.hidden = false; next.focus();
        });
        list.appendChild(b);
      });
      box.appendChild(list);
      next.addEventListener("click", function () { i++; i < data.length ? showQuestion() : showResult(); });
      box.appendChild(next);
    }

    function showResult() {
      box.innerHTML = "";
      var wrap = el("div", "q-result");
      wrap.appendChild(el("div", "score", score + " / " + data.length));
      var msg = score === data.length ? "Тамаша! Барлық жауап дұрыс."
              : score >= 3 ? "Жақсы нәтиже! Сайтты қайта шолып, қалған сұрақтарды да меңгеріп көр."
              : "Сайттағы бөлімдерді қайта оқып, тағы бір рет байқап көр.";
      wrap.appendChild(el("p", "", msg));
      var again = el("button", "btn", "Қайта бастау");
      again.addEventListener("click", function () { i = 0; score = 0; showQuestion(); });
      wrap.appendChild(again);
      box.appendChild(wrap);
    }
    showQuestion();
  }
})();
</script>
</body>
</html>
"""


def build_page() -> str:
    """Уақыт сызығын деректерден HTML-ге айналдырады."""
    items = "\n".join(
        f'<li class="tl-card"><span class="tl-year">{t["жыл"]}</span><p>{t["оқиға"]}</p></li>'
        for t in TIMELINE
    )
    return PAGE.replace("%%TIMELINE%%", items)


@app.get("/", response_class=HTMLResponse)
def home():
    return build_page()


@app.get("/api/info")
def info():
    return INFO


@app.get("/api/tarih")
def tarih():
    return TIMELINE


@app.get("/api/quiz")
def quiz():
    return QUIZ


# Іске қосу:  uvicorn main:app --reload
