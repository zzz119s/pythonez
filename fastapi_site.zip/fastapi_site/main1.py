
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
def home():
    return """
    <html lang="kk">
    <head>
        <meta charset="UTF-8">
        <title>Қазақстан туралы</title>
        <style>
            body {
                font-family: Arial;
                background: #eaf4f8;
                margin: 0;
            }
            header {
                background: #0088aa;
                color: white;
                text-align: center;
                padding: 35px;
            }
            nav {
                background: #005577;
                padding: 15px;
                text-align: center;
            }
            nav a {
                color: white;
                margin: 15px;
                text-decoration: none;
            }
            .card {
                background: white;
                margin: 25px auto;
                padding: 25px;
                max-width: 800px;
                border-radius: 12px;
            }
            footer {
                background: #005577;
                color: white;
                text-align: center;
                padding: 20px;
            }
        </style>
    </head>
    <body>
        <header>
            <h1>Қазақстан Республикасы</h1>
            <p>Ақпараттық веб-сайт</p>
        </header>

        <nav>
            <a href="#about">Қазақстан</a>
            <a href="#history">Тарихы</a>
            <a href="#nature">Табиғаты</a>
        </nav>

        <div class="card" id="about">
            <h2>Қазақстан туралы</h2>
            <p>Қазақстан – тәуелсіз мемлекет.
            Астанасы – Астана қаласы.
            Мемлекеттік тілі – қазақ тілі.</p>
        </div>

        <div class="card" id="history">
            <h2>Тарихы</h2>
            <p>Қазақстан 1991 жылы 16 желтоқсанда
            тәуелсіздігін жариялады.</p>
        </div>

        <div class="card" id="nature">
            <h2>Табиғаты</h2>
            <p>Қазақстанда биік таулар, кең далалар,
            көлдер мен өзендер кездеседі.</p>
        </div>

        <footer>
            © 2026 Қазақстан туралы ақпараттық сайт
        </footer>
    </body>
    </html>
    """

@app.get("/api/info")
def info():
    return {
        "Ел": "Қазақстан",
        "Астанасы": "Астана",
        "Тілі": "Қазақ тілі",
        "Тәуелсіздік": "1991 жыл"
    }