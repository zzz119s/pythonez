from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI(title="Қазақстан туралы ақпараттық сайт")

# ---------------------------------------------------------------
# Деректер (API мен сайт бір дереккөзді пайдаланады)
# ---------------------------------------------------------------
INFO = {
    "Ел": "Қазақстан Республикасы",
    "Астанасы": "Астана",
    "Мемлекеттік тілі": "Қазақ тілі",
    "Тәуелсіздік күні": "1991 жылғы 16 желтоқсан",
    "Аумағы": "шамамен 2,7 млн км²",
    "Халқы": "20 миллионнан астам",
    "Валютасы": "теңге",
    "Әкімшілік бөлінісі": "17 облыс, 3 республикалық маңызы бар қала",
}

TIMELINE = [
    {"жыл": "552", "оқиға": "Түрік қағанаты құрылды."},
    {"жыл": "1465", "оқиға": "Керей мен Жәнібек Қазақ хандығының негізін қалады."},
    {"жыл": "XVIII ғасыр", "оқиға": "Абылай хан бастаған халық жоңғар шапқыншылығына қарсы күресті."},
    {"жыл": "1837–1847", "оқиға": "Кенесары Қасымұлы бастаған ұлт-азаттық қозғалыс."},
    {"жыл": "1917", "оқиға": "Алаш қайраткерлері Алашорда автономиясын жариялады."},
    {"жыл": "1936", "оқиға": "Қазақ Кеңестік Социалистік Республикасы құрылды."},
    {"жыл": "1986", "оқиға": "Алматыда Желтоқсан көтерілісі болды."},
    {"жыл": "1991", "оқиға": "16 желтоқсанда Қазақстан тәуелсіздігін жариялады."},
    {"жыл": "1997", "оқиға": "Елорда Алматыдан Ақмолаға көшірілді, кейін қала Астана аталды."},
]

PAGE = """<!DOCTYPE html>
<html lang="kk">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Қазақстан Республикасы – ақпараттық сайт</title>
<meta name="description" content="Қазақстанның тарихы, табиғаты, мәдениеті және мемлекеттік рәміздері туралы ақпараттық сайт.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&family=PT+Serif:wght@400;700&display=swap&subset=cyrillic,cyrillic-ext" rel="stylesheet">
<style>
:root {
  --sky: #00a5c3;
  --sky-deep: #00758c;
  --night: #072b38;
  --gold: #f4b81b;
  --gold-soft: #fbe3a0;
  --steppe: #5d7b3b;
  --mist: #f1f7f9;
  --ink: #17313b;
  --muted: #4c6670;
  --serif: "PT Serif", Georgia, "Times New Roman", serif;
  --sans: "PT Sans", "Segoe UI", Arial, sans-serif;
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; scroll-padding-top: 76px; }
body {
  margin: 0;
  font-family: var(--sans);
  font-size: 18px;
  line-height: 1.65;
  color: var(--ink);
  background: var(--mist);
}
a { color: inherit; }
:focus-visible { outline: 3px solid var(--gold); outline-offset: 3px; }

.skip {
  position: absolute; left: -999px; top: 8px;
  background: var(--gold); color: var(--night);
  padding: 8px 14px; z-index: 100; font-weight: 700;
}
.skip:focus { left: 8px; }

/* ---------- Навигация ---------- */
.topbar {
  position: sticky; top: 0; z-index: 50;
  background: var(--night);
  border-bottom: 3px solid var(--gold);
}
.topbar-inner {
  max-width: 1100px; margin: 0 auto;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 24px; min-height: 60px; gap: 16px;
}
.brand {
  font-family: var(--serif); font-weight: 700;
  color: #fff; text-decoration: none; font-size: 19px;
}
.menu { display: flex; flex-wrap: wrap; gap: 4px; }
.menu a {
  color: #d6e8ee; text-decoration: none;
  padding: 8px 14px; border-radius: 6px; font-size: 16px;
}
.menu a:hover { background: rgba(255,255,255,.1); color: #fff; }

/* ---------- Басты бөлім ---------- */
.hero {
  position: relative; overflow: hidden;
  background: var(--sky);
  color: #fff;
  padding: 96px 24px 120px;
}
.hero::after {
  /* дала горизонты */
  content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 56px;
  background: var(--steppe);
  clip-path: polygon(0 60%, 12% 35%, 30% 55%, 48% 25%, 66% 50%, 84% 30%, 100% 55%, 100% 100%, 0 100%);
}
.hero-inner { max-width: 1100px; margin: 0 auto; position: relative; z-index: 2; }
.hero h1 {
  font-family: var(--serif);
  font-size: clamp(38px, 6.5vw, 76px);
  line-height: 1.08;
  margin: 0 0 22px;
  max-width: 11em;
}
.hero p.lead {
  font-size: clamp(18px, 2.2vw, 22px);
  max-width: 34em; margin: 0 0 32px;
  color: #effbff;
}
.btn {
  display: inline-block; text-decoration: none; font-weight: 700;
  padding: 13px 26px; border-radius: 8px;
  background: var(--gold); color: var(--night);
}
.btn:hover { background: #ffd04d; }
.btn.ghost { background: transparent; color: #fff; border: 2px solid rgba(255,255,255,.7); margin-left: 10px; }
.btn.ghost:hover { background: rgba(255,255,255,.15); }

.sun {
  position: absolute; z-index: 1;
  right: -90px; top: -90px;
  width: min(520px, 70vw); aspect-ratio: 1; border-radius: 50%;
  background:
    radial-gradient(circle, var(--gold) 0 33%, transparent 33.4%),
    repeating-conic-gradient(var(--gold) 0 3.5deg, transparent 3.5deg 11.25deg);
  -webkit-mask: radial-gradient(circle, #000 0 69%, transparent 69.4%);
          mask: radial-gradient(circle, #000 0 69%, transparent 69.4%);
  animation: rise 1.6s ease-out both;
}
@keyframes rise { from { transform: translateY(80px); opacity: 0; } to { transform: none; opacity: 1; } }

/* ---------- Ою-өрнек жолағы ---------- */
.ornament { display: block; width: 100%; height: 26px; background: var(--night); }

/* ---------- Қысқаша мәлімет ---------- */
.facts {
  background: var(--night); color: #fff;
  padding: 44px 24px 52px;
}
.facts-inner {
  max-width: 1100px; margin: 0 auto;
  display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
  gap: 30px 36px;
}
.fact dt { color: var(--gold); font-size: 15px; margin-bottom: 2px; }
.fact dd { margin: 0; font-family: var(--serif); font-size: 26px; line-height: 1.25; }
.fact dd small { display: block; font-family: var(--sans); font-size: 15px; color: #a9c6d0; margin-top: 2px; }

/* ---------- Мазмұн бөлімдері ---------- */
main { max-width: 1100px; margin: 0 auto; padding: 0 24px; }
section { padding: 76px 0 12px; }
h2 {
  font-family: var(--serif); font-size: clamp(28px, 4vw, 42px);
  line-height: 1.2; margin: 0 0 18px; color: var(--night);
}
h3 { font-family: var(--serif); font-size: 22px; margin: 0 0 8px; color: var(--sky-deep); }
.prose { max-width: 40em; }
.prose p { margin: 0 0 16px; }
.two-col {
  display: grid; grid-template-columns: 1.15fr 1fr; gap: 48px; align-items: start;
}
.aside-box {
  background: #fff; border-left: 6px solid var(--gold);
  padding: 24px 26px; border-radius: 0 10px 10px 0;
}
.aside-box ul { margin: 0; padding-left: 20px; }
.aside-box li { margin-bottom: 8px; }

/* ---------- Тарих: уақыт сызығы ---------- */
.timeline { list-style: none; margin: 32px 0 0; padding: 0; position: relative; max-width: 760px; }
.timeline::before {
  content: ""; position: absolute; left: 118px; top: 6px; bottom: 6px; width: 3px; background: var(--sky);
}
.timeline li {
  display: grid; grid-template-columns: 100px 1fr; gap: 38px;
  padding: 0 0 26px; position: relative;
}
.timeline li::before {
  content: ""; position: absolute; left: 111px; top: 8px;
  width: 17px; height: 17px; border-radius: 50%;
  background: var(--gold); border: 3px solid var(--night);
}
.timeline .year { font-family: var(--serif); font-weight: 700; font-size: 18px; color: var(--sky-deep); text-align: right; }
.timeline .event { padding-left: 14px; }

/* ---------- Табиғат ---------- */
.nature-band {
  background: #fff; border-radius: 14px; padding: 36px;
  margin-top: 28px;
  display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 32px;
}
.nature-band h3 { color: var(--steppe); }
.nature-band p { margin: 0; color: var(--muted); font-size: 17px; }

/* ---------- Мәдениет ---------- */
details {
  background: #fff; border-radius: 10px; margin-bottom: 12px;
  border: 1px solid #d3e4ea;
}
summary {
  cursor: pointer; padding: 18px 24px;
  font-family: var(--serif); font-size: 20px; font-weight: 700; color: var(--night);
  list-style: none; display: flex; justify-content: space-between; align-items: center;
}
summary::-webkit-details-marker { display: none; }
summary::after { content: "+"; font-size: 28px; color: var(--sky-deep); line-height: 1; }
details[open] summary::after { content: "–"; }
details[open] { border-color: var(--sky); }
details .body { padding: 0 24px 20px; color: var(--muted); max-width: 42em; }

/* ---------- Рәміздер ---------- */
.symbols { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 28px; margin-top: 28px; }
.symbol { border-top: 5px solid var(--sky); padding-top: 16px; }
.symbol:nth-child(2) { border-color: var(--gold); }
.symbol:nth-child(3) { border-color: var(--steppe); }
.symbol p { margin: 0; color: var(--muted); }

/* ---------- Төменгі бөлім ---------- */
footer {
  margin-top: 90px; background: var(--night); color: #bcd5dd;
  border-top: 5px solid var(--gold);
  padding: 40px 24px; font-size: 16px;
}
.footer-inner {
  max-width: 1100px; margin: 0 auto;
  display: flex; flex-wrap: wrap; justify-content: space-between; gap: 18px;
}
footer strong { color: #fff; font-family: var(--serif); font-size: 19px; }
footer a { color: var(--gold); }

@media (max-width: 820px) {
  body { font-size: 17px; }
  .two-col { grid-template-columns: 1fr; gap: 28px; }
  .hero { padding: 64px 20px 100px; }
  .btn.ghost { margin: 10px 0 0; }
  .timeline::before { left: 8px; }
  .timeline li { grid-template-columns: 1fr; gap: 2px; padding-left: 34px; }
  .timeline li::before { left: 1px; }
  .timeline .year { text-align: left; }
  .timeline .event { padding-left: 0; }
}
@media (prefers-reduced-motion: reduce) {
  html { scroll-behavior: auto; }
  .sun { animation: none; }
}
</style>
</head>
<body>
<a class="skip" href="#content">Негізгі мазмұнға өту</a>

<div class="topbar">
  <div class="topbar-inner">
    <a class="brand" href="#top">Қазақстан</a>
    <nav class="menu" aria-label="Негізгі мәзір">
      <a href="#about">Ел туралы</a>
      <a href="#history">Тарихы</a>
      <a href="#nature">Табиғаты</a>
      <a href="#culture">Мәдениеті</a>
      <a href="#symbols">Рәміздері</a>
    </nav>
  </div>
</div>

<header class="hero" id="top">
  <div class="sun" aria-hidden="true"></div>
  <div class="hero-inner">
    <h1>Қазақстан Республикасы</h1>
    <p class="lead">Ұланғайыр дала, биік таулар мен ежелгі тарих тоғысқан ел. Мұнда еліміздің тарихы, табиғаты, мәдениеті және мемлекеттік рәміздері туралы қысқаша ақпарат жинақталған.</p>
    <a class="btn" href="#about">Ел туралы оқу</a>
    <a class="btn ghost" href="/api/info">Деректерді JSON түрінде көру</a>
  </div>
</header>

<svg class="ornament" aria-hidden="true" preserveAspectRatio="none">
  <defs>
    <pattern id="orn" width="52" height="26" patternUnits="userSpaceOnUse">
      <path d="M26 2 L38 13 L26 24 L14 13 Z" fill="none" stroke="#f4b81b" stroke-width="2"/>
      <path d="M26 8 L32 13 L26 18 L20 13 Z" fill="#00a5c3"/>
      <circle cx="0" cy="13" r="2.5" fill="#f4b81b"/>
      <circle cx="52" cy="13" r="2.5" fill="#f4b81b"/>
    </pattern>
  </defs>
  <rect width="100%" height="100%" fill="url(#orn)"/>
</svg>

<section class="facts" aria-label="Қысқаша мәлімет">
  <dl class="facts-inner">
    <div class="fact"><dt>Астанасы</dt><dd>Астана<small>1997 жылдан елорда</small></dd></div>
    <div class="fact"><dt>Аумағы</dt><dd>2,7 млн км²<small>әлемде тоғызыншы орын</small></dd></div>
    <div class="fact"><dt>Халқы</dt><dd>20 млн-нан астам<small>130-дан астам ұлт өкілі</small></dd></div>
    <div class="fact"><dt>Тәуелсіздік</dt><dd>16.12.1991<small>Тәуелсіздік күні – 16 желтоқсан</small></dd></div>
    <div class="fact"><dt>Мемлекеттік тілі</dt><dd>Қазақ тілі<small>орыс тілі де ресми қолданылады</small></dd></div>
    <div class="fact"><dt>Валютасы</dt><dd>Теңге<small>1993 жылдан айналымда</small></dd></div>
  </dl>
</section>

<main id="content">

  <section id="about">
    <h2>Қазақстан туралы</h2>
    <div class="two-col">
      <div class="prose">
        <p>Қазақстан – Еуразия құрлығының жүрегінде орналасқан тәуелсіз, егемен мемлекет. Аумағы жағынан ол әлемдегі тоғызыншы, ал теңізге шығу мүмкіндігі жоқ елдердің ішіндегі ең үлкен ел болып саналады.</p>
        <p>Солтүстігі мен батысында Ресеймен, шығысында Қытаймен, оңтүстігінде Қырғызстан, Өзбекстан және Түрікменстанмен шектеседі. Батыс шекарасында Каспий теңізі жатыр.</p>
        <p>Мемлекеттік тілі – қазақ тілі. Астанасы – Астана қаласы. Ел 17 облыс пен республикалық маңызы бар үш қалаға – Астана, Алматы және Шымкентке бөлінеді.</p>
        <p>Қазақстан мұнай, газ, уран, түсті және қара металдарға бай. Уран өндіру көлемі бойынша ел әлемде алдыңғы орындардың бірінде тұр. Сонымен қатар астық шаруашылығы мен мал өсіру дәстүрлі түрде маңызды салалар болып қала береді.</p>
      </div>
      <aside class="aside-box" aria-label="Білгеніңіз жөн">
        <h3>Білгеніңіз жөн</h3>
        <ul>
          <li>Байқоңыр ғарыш айлағы – әлемдегі ең ірі әрі ең ескі ғарыш айлақтарының бірі. 1961 жылы Юрий Гагарин осы жерден ғарышқа аттанған.</li>
          <li>Астана 1998 жылы елорда ретінде халықаралық деңгейде таныстырылды, ал бұған дейін қала Ақмола деп аталды.</li>
          <li>Қазақстанда Түркістан қаласындағы Қожа Ахмет Ясауи кесенесі сияқты ЮНЕСКО-ның Бүкіләлемдік мұра нысандары бар.</li>
        </ul>
      </aside>
    </div>
  </section>

  <section id="history">
    <h2>Тарихы</h2>
    <div class="prose">
      <p>Қазақ жерінде адамдар тас дәуірінен бері мекендеген. Сақтар, үйсіндер, қаңлылар және ғұндар сияқты ежелгі тайпалар дала өркениетінің негізін қалады. Ұлы Жібек жолы осы өңір арқылы өтіп, Шығыс пен Батысты байланыстырды.</p>
      <p>Қазақ хандығы 1465 жылы құрылып, қазақ халқының біртұтас мемлекеттілігі қалыптасты. Кейінгі ғасырларда жоңғар шапқыншылығына қарсы күрес, Ресей империясының құрамындағы ауыр кезең, 1917 жылғы Алаш қозғалысы және Кеңес дәуірі елдің тағдырына терең із қалдырды.</p>
    </div>
    <ol class="timeline" aria-label="Тарихи оқиғалар хронологиясы">
      %%TIMELINE%%
    </ol>
    <div class="prose" style="margin-top:20px">
      <p>1991 жылы 16 желтоқсанда Қазақстан Республикасы өзінің мемлекеттік тәуелсіздігін жариялады. Осыдан бері ел өз экономикасын, сыртқы саясатын және ұлттық бірегейлігін нығайтып келеді.</p>
    </div>
  </section>

  <section id="nature">
    <h2>Табиғаты</h2>
    <div class="prose">
      <p>Қазақстан табиғаты өте сан алуан: жазықтардың шексіз даласынан бастап мұзарттар жататын тау шыңдарына дейін. Елде шөл, шөлейт, дала, орманды дала және тау белдеулері бар.</p>
    </div>
    <div class="nature-band">
      <div>
        <h3>Таулар</h3>
        <p>Оңтүстік-шығыста Тянь-Шань мен Жетісу (Жоңғар) Алатауы, шығыста Алтай тауы орналасқан. Ең биік шыңдардың бірі – шамамен 7 мың метрге жететін Хан Тәңірі.</p>
      </div>
      <div>
        <h3>Көлдер мен өзендер</h3>
        <p>Балқаш көлінің бір бөлігі тұщы, екінші бөлігі тұзды. Ертіс, Есіл, Сырдария және Жайық – ірі өзендер. Каспий мен Арал теңіздері де елдің су қорының маңызды бөлігі.</p>
      </div>
      <div>
        <h3>Табиғат ескерткіштері</h3>
        <p>Шарын шатқалы, Бурабай мен Баянауыл ұлттық саябақтары, Қатонқарағай және Алтын-Емел өңірлері саяхатшыларды жыл сайын өзіне тартады.</p>
      </div>
      <div>
        <h3>Жануарлар дүниесі</h3>
        <p>Қар барысы, архар, бүркіт, дала қыраны және ақбөкен (киік) – еліміздің танымал жануарлары. Ақбөкен популяциясын сақтау үшін арнайы шаралар қабылданады.</p>
      </div>
    </div>
  </section>

  <section id="culture">
    <h2>Мәдениеті мен дәстүрі</h2>
    <div class="prose">
      <p>Қазақ мәдениеті көшпелі өмір салтымен тығыз байланысты. Қонақжайлылық, үлкенді сыйлау және ауызбіршілік – халықтың ең басты құндылықтары. Төмендегі тақырыптарды ашып оқуға болады.</p>
    </div>
    <div style="margin-top:24px">
      <details>
        <summary>Наурыз мерекесі</summary>
        <div class="body">Наурыз – көктемнің келуін, табиғаттың жаңаруын білдіретін ең көне мереке. Қазақстанда ол 21–23 наурыз аралығында аталып өтеді. Осы күндері наурыз көже дайындалып, ұлттық ойындар ұйымдастырылады.</div>
      </details>
      <details>
        <summary>Домбыра мен күй өнері</summary>
        <div class="body">Домбыра – екі ішекті ұлттық аспап. Құрманғазы, Дәулеткерей, Тәттімбет сияқты күйшілердің шығармалары қазақ музыкасының алтын қорын құрайды. Ән мен жыр, айтыс өнері де қазақ рухани мәдениетінің маңызды бөлігі.</div>
      </details>
      <details>
        <summary>Ұлттық тағамдар</summary>
        <div class="body">Ең танымал тағам – бешбармақ, яғни ет пен қамыр. Сонымен қатар қуырдақ, сорпа, бауырсақ дайындалады. Сусындардан қымыз, шұбат және айран кеңінен таралған. Дастархан басында қонақты күту ерекше құрметке жатады.</div>
      </details>
      <details>
        <summary>Киіз үй мен қолөнер</summary>
        <div class="body">Киіз үй – көшпенділердің ыңғайлы әрі берік баспанасы. Оның төбесіндегі шаңырақ Қазақстанның мемлекеттік рәмізінде де бейнеленген. Киіз басу, кілем тоқу, зергерлік және ағаш өңдеу – ғасырлар бойы дамыған қолөнер түрлері.</div>
      </details>
      <details>
        <summary>Ұлы тұлғалар</summary>
        <div class="body">Әл-Фараби – ортағасырлық ғұлама ойшыл, «Екінші ұстаз» атанған. Абай Құнанбайұлы – қазақ жазба әдебиетінің негізін қалаушы, «Қара сөздер» авторы. Мұхтар Әуезов – «Абай жолы» эпопеясын жазған жазушы. Олар қазақ халқының рухани мұрасын әлемге танытты.</div>
      </details>
    </div>
  </section>

  <section id="symbols">
    <h2>Мемлекеттік рәміздер</h2>
    <div class="prose">
      <p>Мемлекеттік рәміздер – ел бірлігі мен егемендігінің белгісі. Олардың әрқайсысында халықтың тарихы мен арманы көрініс тапқан.</p>
    </div>
    <div class="symbols">
      <div class="symbol">
        <h3>Ту</h3>
        <p>Аспан түстес кенепте шуақты күн мен оның астында қалықтаған қыран бейнеленген. Туды 1992 жылы суретші Шәкен Ниязбеков жасаған. Ту жағасында ұлттық оюмен өрнектелген жолақ бар.</p>
      </div>
      <div class="symbol">
        <h3>Елтаңба</h3>
        <p>Елтаңбаның негізінде шаңырақ тұр. Оны екі жағынан қанатты тұлпарлар қолдап тұр, ал жоғарыда жұлдыз орналасқан. Елтаңбаны Жандарбек Мәлібеков пен Шота Уәлиханов жасаған.</p>
      </div>
      <div class="symbol">
        <h3>Әнұран</h3>
        <p>«Менің Қазақстаным» әні 2006 жылдан бері мемлекеттік әнұран болып табылады. Әнұранның әні Шәмші Қалдаяковқа тиесілі.</p>
      </div>
    </div>
  </section>

</main>

<footer>
  <div class="footer-inner">
    <div>
      <strong>Қазақстан Республикасы</strong><br>
      Ақпараттық веб-сайт · FastAPI арқылы жасалған
    </div>
    <div>
      <a href="/api/info">/api/info</a> ·
      <a href="/api/tarih">/api/tarih</a> ·
      <a href="/docs">API құжаттамасы</a><br>
      © 2026 Қазақстан туралы ақпараттық сайт
    </div>
  </div>
</footer>
</body>
</html>
"""


def build_page() -> str:
    """Уақыт сызығын деректерден HTML-ге айналдырады."""
    items = "\n".join(
        f'<li><span class="year">{t["жыл"]}</span><span class="event">{t["оқиға"]}</span></li>'
        for t in TIMELINE
    )
    return PAGE.replace("%%TIMELINE%%", items)


@app.get("/", response_class=HTMLResponse)
def home():
    return build_page()


@app.get("/api/info")
def info():
    return INFO


@app.get("/api/tarih")
def tarih():
    return TIMELINE


# Іске қосу:  uvicorn main:app --reload
