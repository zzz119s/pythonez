"""
Қазақстан туралы ақпараттық сайт – Tkinter нұсқасы (жұмыс үстелі қосымшасы).
Тек стандартты кітапхана керек, қосымша орнату жоқ.
Іске қосу:  python main_tk.py
"""
import math
import tkinter as tk
from tkinter import font as tkfont

# ---------------------------------------------------------------
# Деректер
# ---------------------------------------------------------------
TIMELINE = [
    ("552", "Түрік қағанаты құрылды."),
    ("1465", "Керей мен Жәнібек Қазақ хандығының негізін қалады."),
    ("XVIII ғ.", "Абылай хан бастаған халық жоңғар шапқыншылығына қарсы күресті."),
    ("1837–1847", "Кенесары Қасымұлы бастаған ұлт-азаттық қозғалыс."),
    ("1917", "Алаш қайраткерлері Алашорда автономиясын жариялады."),
    ("1936", "Қазақ Кеңестік Социалистік Республикасы құрылды."),
    ("1986", "Алматыда Желтоқсан көтерілісі болды."),
    ("1991", "16 желтоқсанда Қазақстан тәуелсіздігін жариялады."),
    ("1997", "Елорда Алматыдан Ақмолаға көшірілді, кейін қала Астана аталды."),
]

NATURE = [
    {"tab": "Таулар", "title": "Тянь-Шань, Жетісу Алатауы, Алтай",
     "text": "Оңтүстік-шығыста Тянь-Шань мен Жетісу (Жоңғар) Алатауы, шығыста Алтай тауы орналасқан. "
             "Бұл өңірлерде мұздықтар, альпі шалғындары және қылқан жапырақты ормандар кездеседі.",
     "bullets": ["Алматы маңындағы Іле Алатауы", "Алтайдағы Берел және Катонқарағай алқабы"],
     "big": "≈7 000 м", "cap": "Хан Тәңірі – елдегі ең биік шыңдардың бірі", "color": "#1b4e68"},
    {"tab": "Су көздері", "title": "Көлдер, өзендер, теңіздер",
     "text": "Балқаш көлінің бір бөлігі тұщы, екінші бөлігі тұзды. Ертіс, Есіл, Сырдария және Жайық – ірі өзендер. "
             "Каспий мен Арал теңіздері де елдің су қорының маңызды бөлігі.",
     "bullets": ["Балқаш пен Зайсан – ірі көлдер", "Солтүстік Арал теңізі қалпына келтіріліп жатыр"],
     "big": "Балқаш", "cap": "бір көлде тұщы да, тұзды да су", "color": "#0079a3"},
    {"tab": "Саябақтар", "title": "Табиғат ескерткіштері",
     "text": "Шарын шатқалы, Бурабай мен Баянауыл ұлттық саябақтары, Алтын-Емел өңірі саяхатшыларды "
             "жыл сайын өзіне тартады. Әрқайсысының өз ландшафты, өз аңызы бар.",
     "bullets": ["Шарын – қызыл құзды шатқал", "Бурабай – «Қазақстанның Швейцариясы»"],
     "big": "Шарын", "cap": "миллиондаған жылда қалыптасқан шатқал", "color": "#4a6b2a"},
    {"tab": "Жануарлар", "title": "Жануарлар дүниесі",
     "text": "Қар барысы, архар, бүркіт, дала қыраны және ақбөкен (киік) – еліміздің танымал жануарлары. "
             "Ақбөкен популяциясын сақтау үшін арнайы шаралар қабылданады.",
     "bullets": ["Қар барысы – таудың сирек мекендеушісі", "Ақбөкен – дала антилопасы"],
     "big": "Ақбөкен", "cap": "даланың ең танымал тұяқтыларының бірі", "color": "#a8631b"},
]

CULTURE = [
    ("Наурыз мерекесі", "Көктемнің келуін, табиғаттың жаңаруын білдіретін ең көне мереке. Қазақстанда 21–23 наурыз "
     "аралығында аталып өтеді: наурыз көже дайындалады, ұлттық ойындар ұйымдастырылады.", "gold"),
    ("Домбыра мен күй", "Домбыра – екі ішекті ұлттық аспап. Құрманғазы, Дәулеткерей, Тәттімбет сияқты күйшілердің "
     "шығармалары қазақ музыкасының алтын қорын құрайды. Ән, жыр және айтыс та рухани мұраның бөлігі.", "surface"),
    ("Ұлттық тағамдар", "Бешбармақ – ең танымал тағам. Қуырдақ, сорпа, бауырсақ, қымыз, шұбат және айран да "
     "дастарханның құрметті бөлігі.", "surface"),
    ("Киіз үй", "Көшпенділердің ыңғайлы әрі берік баспанасы. Төбесіндегі шаңырақ Қазақстан елтаңбасында да "
     "бейнеленген. Киіз басу, кілем тоқу, зергерлік – ғасырлар бойы дамыған қолөнер.", "grass"),
    ("Ұлы тұлғалар", "Әл-Фараби – «Екінші ұстаз» атанған ғұлама. Абай – қазақ жазба әдебиетінің негізін қалаушы. "
     "Мұхтар Әуезов – «Абай жолы» эпопеясының авторы.", "surface2"),
]

QUIZ = [
    ("Қазақстан тәуелсіздігін қай жылы жариялады?", ["1989", "1991", "1993", "1995"], 1),
    ("Қазақ хандығы қай жылы құрылды?", ["1365", "1465", "1565", "1665"], 1),
    ("Қазақстанның астанасы қай қала?", ["Астана", "Алматы", "Шымкент", "Қарағанды"], 0),
    ("Наурыз мерекесі қай мезгілдің келуін білдіреді?", ["Жаздың", "Күздің", "Қыстың", "Көктемнің"], 3),
    ("Қай көлдің бір бөлігі тұщы, екінші бөлігі тұзды?", ["Балқаш", "Байкал", "Зайсан", "Бурабай"], 0),
]

ABOUT = [
    "Қазақстан – Еуразия құрлығының жүрегінде орналасқан тәуелсіз, егемен мемлекет. Аумағы жағынан ол әлемдегі "
    "тоғызыншы, ал теңізге шығуы жоқ елдердің ішіндегі ең үлкен ел.",
    "Солтүстігі мен батысында Ресеймен, шығысында Қытаймен, оңтүстігінде Қырғызстан, Өзбекстан және Түрікменстанмен "
    "шектеседі. Батыс шекарасында Каспий теңізі жатыр.",
    "Мемлекеттік тілі – қазақ тілі, астанасы – Астана. Ел 17 облыс пен республикалық маңызы бар үш қалаға – "
    "Астана, Алматы және Шымкентке бөлінеді.",
    "Қазақстан мұнай, газ, уран, түсті және қара металдарға бай. Астық шаруашылығы мен мал өсіру де маңызды салалар.",
]

# ---------------------------------------------------------------
# Түстер
# ---------------------------------------------------------------
SKY, GOLD, GRASS = "#00afca", "#ffc83d", "#5e8238"
THEMES = {
    "dark": dict(bg="#071218", surface="#0d1d26", surface2="#132f3c", text="#eaf4f8", muted="#94b0bc"),
    "light": dict(bg="#f2f7f9", surface="#ffffff", surface2="#e3eff4", text="#0b1d25", muted="#476370"),
}


# ---------------------------------------------------------------
# Көмекші виджеттер
# ---------------------------------------------------------------
class Wrap(tk.Label):
    """Ені өзгергенде мәтінді автоматты түрде жолға бөлетін Label."""
    def __init__(self, parent, **kw):
        kw.setdefault("justify", "left")
        kw.setdefault("anchor", "w")
        kw.setdefault("wraplength", 300)
        super().__init__(parent, **kw)
        self.bind("<Configure>", lambda e: self.configure(wraplength=max(e.width - 4, 80)))


def make_button(parent, text, command, bg, fg, hover=None, font=None, padx=22, pady=10):
    """Label негізіндегі батырма (барлық платформада түсі дұрыс көрінеді)."""
    b = tk.Label(parent, text=text, bg=bg, fg=fg, font=font, padx=padx, pady=pady, cursor="hand2")
    b._cmd, b._bg, b._hover = command, bg, hover or bg
    b.bind("<Button-1>", lambda e: b._cmd and b._cmd())
    b.bind("<Enter>", lambda e: b._cmd and b.configure(bg=b._hover))
    b.bind("<Leave>", lambda e: b.configure(bg=b._bg))
    return b


def restyle(b, bg, fg):
    """Батырманың түсін тұрақты өзгерту (Leave оқиғасы қайтып алмауы үшін)."""
    b._bg = bg
    b.configure(bg=bg, fg=fg)


class ScrollFrame(tk.Frame):
    def __init__(self, parent, bg):
        super().__init__(parent, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0)
        bar = tk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self._win, width=e.width))


# ---------------------------------------------------------------
# Қосымша
# ---------------------------------------------------------------
class App(tk.Tk):
    NAV = [("home", "Басты бет"), ("history", "Тарихы"), ("nature", "Табиғаты"),
           ("culture", "Мәдениеті"), ("symbols", "Рәміздері"), ("quiz", "Викторина")]

    def __init__(self):
        super().__init__()
        self.title("Қазақстан Республикасы – ақпараттық қосымша")
        self.geometry("1120x740")
        self.minsize(960, 620)

        families = set(tkfont.families())
        self.family = next((f for f in ("Segoe UI", "Inter", "Helvetica Neue", "Arial", "DejaVu Sans")
                            if f in families), "TkDefaultFont")
        self.theme = "dark"
        self.page = "home"
        self.scroller = None
        self.nav_labels = {}

        self.body = tk.Frame(self)
        self.body.pack(fill="both", expand=True)
        self.build_layout()
        self.show("home")

        self.bind_all("<MouseWheel>", self._wheel)
        self.bind_all("<Button-4>", self._wheel)
        self.bind_all("<Button-5>", self._wheel)

    # ---- түстер мен қаріптер ----
    @property
    def c(self):
        return THEMES[self.theme]

    def f(self, size, bold=False):
        return (self.family, size, "bold" if bold else "normal")

    def _wheel(self, e):
        if not self.scroller:
            return
        if e.num == 4:
            step = -2
        elif e.num == 5:
            step = 2
        else:
            step = -int(e.delta / 120) * 2 if abs(e.delta) >= 120 else -e.delta
        self.scroller.canvas.yview_scroll(step, "units")

    # ---- жалпы макет ----
    def build_layout(self):
        for w in self.body.winfo_children():
            w.destroy()
        self.body.configure(bg=self.c["bg"])
        self.side = tk.Frame(self.body, bg=self.c["surface"], width=220)
        self.side.pack(side="left", fill="y")
        self.side.pack_propagate(False)
        self.content = tk.Frame(self.body, bg=self.c["bg"])
        self.content.pack(side="left", fill="both", expand=True)

        tk.Label(self.side, text="Қазақстан", bg=self.c["surface"], fg=self.c["text"],
                 font=self.f(20, True), anchor="w").pack(fill="x", padx=24, pady=(28, 4))
        tk.Label(self.side, text="Ақпараттық қосымша", bg=self.c["surface"], fg=self.c["muted"],
                 font=self.f(10), anchor="w").pack(fill="x", padx=24, pady=(0, 24))

        self.nav_labels = {}
        for key, text in self.NAV:
            lab = tk.Label(self.side, text=text, anchor="w", padx=18, pady=10, cursor="hand2",
                           font=self.f(12), bg=self.c["surface"], fg=self.c["muted"])
            lab.pack(fill="x", padx=12, pady=2)
            lab.bind("<Button-1>", lambda e, k=key: self.show(k))
            lab.bind("<Enter>", lambda e, k=key: self._nav_hover(k, True))
            lab.bind("<Leave>", lambda e, k=key: self._nav_hover(k, False))
            self.nav_labels[key] = lab

        label = "☀  Күндізгі режим" if self.theme == "dark" else "☾  Түнгі режим"
        make_button(self.side, label, self.toggle_theme, self.c["surface2"], self.c["text"],
                    font=self.f(11)).pack(side="bottom", fill="x", padx=16, pady=20)

    def _nav_hover(self, key, inside):
        if key == self.page:
            return
        self.nav_labels[key].configure(bg=self.c["surface2"] if inside else self.c["surface"],
                                       fg=self.c["text"] if inside else self.c["muted"])

    def _mark_nav(self):
        for k, lab in self.nav_labels.items():
            active = k == self.page
            lab.configure(bg=GOLD if active else self.c["surface"],
                          fg="#1b1400" if active else self.c["muted"],
                          font=self.f(12, active))

    def toggle_theme(self):
        self.theme = "light" if self.theme == "dark" else "dark"
        self.build_layout()
        self.show(self.page)

    def show(self, key):
        self.page = key
        for w in self.content.winfo_children():
            w.destroy()
        self.scroller = ScrollFrame(self.content, self.c["bg"])
        self.scroller.pack(fill="both", expand=True)
        self.scroller.canvas.yview_moveto(0)
        getattr(self, "page_" + key)(self.scroller.inner)
        self._mark_nav()

    # ---- көмекші элементтер ----
    def heading(self, parent, text, sub=None):
        box = tk.Frame(parent, bg=self.c["bg"])
        box.pack(fill="x", padx=36, pady=(32, 16))
        tk.Label(box, text=text, bg=self.c["bg"], fg=self.c["text"], font=self.f(28, True),
                 anchor="w").pack(fill="x")
        if sub:
            Wrap(box, text=sub, bg=self.c["bg"], fg=self.c["muted"], font=self.f(12)).pack(fill="x", pady=(6, 0))

    def card(self, parent, kind="surface"):
        colors = {"surface": (self.c["surface"], self.c["text"], self.c["muted"]),
                  "surface2": (self.c["surface2"], self.c["text"], self.c["muted"]),
                  "gold": (GOLD, "#1b1400", "#3a2d00"),
                  "grass": (GRASS, "#ffffff", "#eaf4dd"),
                  "sky": (SKY, "#04222b", "#06323f")}
        bg, fg, sub = colors[kind]
        fr = tk.Frame(parent, bg=bg, padx=24, pady=20)
        return fr, bg, fg, sub

    # ===========================================================
    # Басты бет
    # ===========================================================
    def page_home(self, parent):
        hero = tk.Canvas(parent, height=330, highlightthickness=0, bg="#06161d")
        hero.pack(fill="x")
        hero.bind("<Configure>", lambda e: self._draw_hero(hero))

        stats = tk.Frame(parent, bg=self.c["bg"])
        stats.pack(fill="x", padx=36, pady=(24, 8))
        data = [("2,7", " млн км²", "аумағы бойынша әлемде 9-орын", "sky", 2.7, 1),
                ("20", "+ млн", "халық, 130-дан астам ұлт", "surface", 20, 0),
                ("17", "", "облыс және 3 қала", "surface", 17, 0),
                ("1991", "", "тәуелсіздік жылы", "gold", 1991, 0)]
        for i, (num, suffix, cap, kind, end, dec) in enumerate(data):
            stats.columnconfigure(i, weight=1, uniform="stat")
            fr, bg, fg, sub = self.card(stats, kind)
            fr.grid(row=0, column=i, sticky="nsew", padx=6)
            val = tk.Label(fr, text=num + suffix, bg=bg, fg=fg, font=self.f(26, True), anchor="w")
            val.pack(fill="x")
            Wrap(fr, text=cap, bg=bg, fg=sub, font=self.f(10)).pack(fill="x", pady=(4, 0))
            self._count_up(val, end, dec, suffix, plain=(end == 1991))

        self.heading(parent, "Қазақстан туралы")
        fr, bg, fg, sub = self.card(parent, "surface")
        fr.pack(fill="x", padx=42, pady=(0, 14))
        for p in ABOUT:
            Wrap(fr, text=p, bg=bg, fg=fg, font=self.f(12)).pack(fill="x", pady=6)

        row = tk.Frame(parent, bg=self.c["bg"])
        row.pack(fill="x", padx=36, pady=(0, 36))
        for i, (t, d, kind) in enumerate([
            ("Байқоңыр", "Әлемдегі ең ірі әрі ең көне ғарыш айлақтарының бірі. 1961 жылы Юрий Гагарин осы жерден ғарышқа ұшқан.", "surface2"),
            ("Елорда", "Астана 1997 жылдан бері елорда, ал 1998 жылы халықаралық деңгейде таныстырылды. Бұған дейін қала Ақмола деп аталған.", "surface"),
            ("ЮНЕСКО мұрасы", "Түркістандағы Қожа Ахмет Ясауи кесенесі сияқты нысандар Бүкіләлемдік мұра тізіміне енген.", "surface")]):
            row.columnconfigure(i, weight=1, uniform="fact")
            fr, bg, fg, sub = self.card(row, kind)
            fr.grid(row=0, column=i, sticky="nsew", padx=6)
            tk.Label(fr, text=t, bg=bg, fg=fg, font=self.f(14, True), anchor="w").pack(fill="x")
            Wrap(fr, text=d, bg=bg, fg=sub, font=self.f(11)).pack(fill="x", pady=(6, 0))

    def _count_up(self, label, end, dec, suffix, plain, frames=40):
        def fmt(v):
            s = f"{v:.{dec}f}".replace(".", ",") if dec else str(int(round(v)))
            return s + suffix
        def step(n=0):
            if not label.winfo_exists():
                return
            p = n / frames
            eased = 1 - (1 - p) ** 3
            label.configure(text=fmt(end * eased))
            if n < frames:
                label.after(25, step, n + 1)
        step()

    def _draw_hero(self, c):
        c.delete("all")
        w = max(c.winfo_width(), 400)
        h = int(c["height"])
        c.create_rectangle(0, 0, w, h, fill="#06161d", outline="")
        c.create_oval(-120, -100, 360, 320, fill="#0a3a48", outline="")  # жайлы жарық дақ
        c.create_oval(w - 520, h - 380, w + 80, h + 120, fill="#0b2a2f", outline="")
        cx, cy, r = w - 190, 150, 62
        for i in range(32):
            a = math.radians(i * 11.25)
            r1, r2 = r * 1.28, r * (1.85 if i % 2 == 0 else 1.6)
            c.create_line(cx + r1 * math.cos(a), cy + r1 * math.sin(a),
                          cx + r2 * math.cos(a), cy + r2 * math.sin(a),
                          fill=GOLD, width=4, capstyle="round")
        c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=GOLD, outline="")
        c.create_oval(cx - r * .55, cy - r * .55, cx + r * .55, cy + r * .55, fill="#fff1c2", outline="")
        c.create_text(40, 105, anchor="w", text="Қазақстан\nРеспубликасы", fill="white",
                      font=self.f(40, True), justify="left")
        c.create_text(42, 222, anchor="nw", fill="#c4dce5", font=self.f(13), width=max(w - 420, 260),
                      text="Ұланғайыр дала, биік таулар мен ежелгі тарих тоғысқан ел.")
        pts = [0, .72, .1, .55, .24, .68, .4, .42, .56, .64, .72, .38, .88, .6, 1, .46]
        poly = []
        for i in range(0, len(pts), 2):
            poly += [pts[i] * w, h - 60 + pts[i + 1] * 60 - 30]
        poly += [w, h, 0, h]
        c.create_polygon(poly, fill=self.c["bg"], outline="")

    # ===========================================================
    # Тарих
    # ===========================================================
    def page_history(self, parent):
        self.heading(parent, "Тарихы",
                     "Сақтар, үйсіндер, қаңлылар мен ғұндардан бастап тәуелсіздікке дейінгі қазақ даласының ұзақ жолы. "
                     "Ұлы Жібек жолы осы өңір арқылы Шығыс пен Батысты байланыстырды.")
        wrap = tk.Frame(parent, bg=self.c["bg"])
        wrap.pack(fill="x", padx=36, pady=(0, 36))
        for i, (year, text) in enumerate(TIMELINE):
            row = tk.Frame(wrap, bg=self.c["bg"])
            row.pack(fill="x")
            row.columnconfigure(2, weight=1)
            tk.Label(row, text=year, bg=self.c["bg"], fg=SKY, font=self.f(15, True),
                     width=10, anchor="e").grid(row=0, column=0, sticky="n", pady=(12, 0))
            dot = tk.Canvas(row, width=36, highlightthickness=0, bg=self.c["bg"])
            dot.grid(row=0, column=1, sticky="ns")
            dot.bind("<Configure>", lambda e, cv=dot, first=(i == 0), last=(i == len(TIMELINE) - 1):
                     self._draw_dot(cv, first, last))
            last = i == len(TIMELINE) - 1
            fr, bg, fg, sub = self.card(row, "sky" if last else "surface")
            fr.grid(row=0, column=2, sticky="ew", pady=6)
            Wrap(fr, text=text, bg=bg, fg=fg, font=self.f(12)).pack(fill="x")

    def _draw_dot(self, cv, first, last):
        cv.delete("all")
        h = cv.winfo_height()
        top = 24 if first else 0
        bottom = 24 if last else h
        cv.create_line(18, top, 18, bottom, fill=self.c["surface2"], width=3)
        cv.create_oval(10, 16, 26, 32, fill=GOLD, outline=self.c["bg"], width=3)

    # ===========================================================
    # Табиғат
    # ===========================================================
    def page_nature(self, parent):
        self.heading(parent, "Табиғаты",
                     "Жазықтардың шексіз даласынан мұзарттар жататын шыңдарға дейін: Қазақстанда шөл, шөлейт, дала, "
                     "орманды дала және тау белдеулері бар.")
        bar = tk.Frame(parent, bg=self.c["bg"])
        bar.pack(fill="x", padx=36, pady=(0, 12))
        area = tk.Frame(parent, bg=self.c["bg"])
        area.pack(fill="x", padx=36, pady=(0, 36))
        tabs = []

        def select(i):
            for j, t in enumerate(tabs):
                on = j == i
                restyle(t, self.c["text"] if on else self.c["surface"],
                        self.c["bg"] if on else self.c["muted"])
            for w in area.winfo_children():
                w.destroy()
            d = NATURE[i]
            area.columnconfigure(0, weight=3, uniform="n")
            area.columnconfigure(1, weight=2, uniform="n")
            fr, bg, fg, sub = self.card(area, "surface")
            fr.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
            tk.Label(fr, text=d["title"], bg=bg, fg=fg, font=self.f(16, True), anchor="w").pack(fill="x")
            Wrap(fr, text=d["text"], bg=bg, fg=sub, font=self.f(12)).pack(fill="x", pady=(10, 8))
            for b in d["bullets"]:
                Wrap(fr, text="•  " + b, bg=bg, fg=fg, font=self.f(11)).pack(fill="x", pady=2)
            vis = tk.Frame(area, bg=d["color"], padx=24, pady=20)
            vis.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
            tk.Label(vis, text="", bg=d["color"]).pack(expand=True)
            tk.Label(vis, text=d["big"], bg=d["color"], fg="white", font=self.f(30, True), anchor="w").pack(fill="x")
            Wrap(vis, text=d["cap"], bg=d["color"], fg="#e8f3f7", font=self.f(11)).pack(fill="x", pady=(4, 0))

        for i, d in enumerate(NATURE):
            t = make_button(bar, d["tab"], lambda i=i: select(i), self.c["surface"], self.c["muted"],
                            font=self.f(11, True), padx=18, pady=8)
            t.pack(side="left", padx=(0, 8))
            tabs.append(t)
        select(0)

    # ===========================================================
    # Мәдениет
    # ===========================================================
    def page_culture(self, parent):
        self.heading(parent, "Мәдениеті мен дәстүрі",
                     "Қазақ мәдениеті көшпелі өмір салтымен тығыз байланысты. Қонақжайлылық, үлкенді сыйлау және "
                     "ауызбіршілік – халықтың басты құндылықтары.")
        grid = tk.Frame(parent, bg=self.c["bg"])
        grid.pack(fill="x", padx=30, pady=(0, 36))
        for col in (0, 1):
            grid.columnconfigure(col, weight=1, uniform="cul")
        for i, (title, text, kind) in enumerate(CULTURE):
            fr, bg, fg, sub = self.card(grid, kind)
            span = 2 if i == len(CULTURE) - 1 else 1
            fr.grid(row=i // 2, column=i % 2, columnspan=span, sticky="nsew", padx=6, pady=6)
            tk.Label(fr, text=title, bg=bg, fg=fg, font=self.f(15, True), anchor="w").pack(fill="x")
            Wrap(fr, text=text, bg=bg, fg=sub, font=self.f(12)).pack(fill="x", pady=(8, 0))

    # ===========================================================
    # Рәміздер
    # ===========================================================
    def page_symbols(self, parent):
        self.heading(parent, "Мемлекеттік рәміздер",
                     "Рәміздер – ел бірлігі мен егемендігінің белгісі. Әрқайсысында халықтың тарихы мен арманы көрініс тапқан.")
        items = [
            ("Ту", "Аспан түстес кенепте шуақты күн мен оның астында қалықтаған қыран бейнеленген. Туды 1992 жылы "
                   "суретші Шәкен Ниязбеков жасаған. Ту жағасында ұлттық оюмен өрнектелген жолақ бар.", self._draw_flag),
            ("Елтаңба", "Негізінде шаңырақ тұр. Оны екі жағынан қанатты тұлпарлар қолдап тұр, ал жоғарыда жұлдыз "
                        "орналасқан. Елтаңбаны Жандарбек Мәлібеков пен Шота Уәлиханов жасаған.", self._draw_arms),
            ("Әнұран", "«Менің Қазақстаным» әні 2006 жылдан бері мемлекеттік әнұран болып табылады. "
                        "Әнұранның әні Шәмші Қалдаяковқа тиесілі.", self._draw_anthem),
        ]
        for title, text, draw in items:
            fr, bg, fg, sub = self.card(parent, "surface")
            fr.pack(fill="x", padx=42, pady=8)
            fr.columnconfigure(1, weight=1)
            cv = tk.Canvas(fr, width=300, height=160, highlightthickness=0, bg=bg)
            cv.grid(row=0, column=0, rowspan=2, padx=(0, 24))
            draw(cv)
            tk.Label(fr, text=title, bg=bg, fg=fg, font=self.f(18, True), anchor="w").grid(row=0, column=1, sticky="sw")
            Wrap(fr, text=text, bg=bg, fg=sub, font=self.f(12)).grid(row=1, column=1, sticky="new", pady=(6, 0))
        tk.Frame(parent, bg=self.c["bg"], height=30).pack()

    def _draw_flag(self, c):
        c.create_rectangle(0, 0, 300, 160, fill=SKY, outline="")
        for i in range(16):
            a = math.radians(i * 22.5)
            c.create_line(150 + 24 * math.cos(a), 60 + 24 * math.sin(a),
                          150 + 36 * math.cos(a), 60 + 36 * math.sin(a), fill=GOLD, width=3, capstyle="round")
        c.create_oval(134, 44, 166, 76, fill=GOLD, outline="")
        bird = [92, 118, 118, 100, 138, 106, 150, 112, 162, 106, 182, 100, 208, 118,
                186, 112, 166, 116, 150, 126, 134, 116, 114, 112]
        c.create_polygon(bird, fill=GOLD, outline="", smooth=True)
        c.create_rectangle(10, 10, 26, 150, outline=GOLD, width=2)
        for y in (24, 52, 80, 108):
            c.create_polygon(18, y, 23, y + 8, 18, y + 16, 13, y + 8, fill=GOLD, outline="")

    def _draw_arms(self, c):
        c.create_rectangle(0, 0, 300, 160, fill="#0d3a4a", outline="")
        c.create_oval(88, 20, 212, 144, fill=SKY, outline=GOLD, width=5)
        for i in range(8):
            a = math.radians(i * 45)
            c.create_line(150, 82, 150 + 48 * math.cos(a), 82 + 48 * math.sin(a), fill=GOLD, width=3, capstyle="round")
        c.create_oval(128, 60, 172, 104, outline=GOLD, width=3)
        star = []
        for i in range(10):
            rad = 11 if i % 2 == 0 else 5
            a = math.radians(-90 + i * 36)
            star += [150 + rad * math.cos(a), 20 + rad * math.sin(a)]
        c.create_polygon(star, fill=GOLD, outline="")

    def _draw_anthem(self, c):
        c.create_rectangle(0, 0, 300, 160, fill="#1c3a1a", outline="")
        heights = [32, 64, 100, 52, 84, 120, 76, 44, 92, 56, 24]
        for i, hh in enumerate(heights):
            x = 30 + i * 22
            c.create_rectangle(x, 80 - hh / 2, x + 10, 80 + hh / 2,
                               fill=GOLD if hh == 120 else "#6b9140", outline="")

    # ===========================================================
    # Викторина
    # ===========================================================
    def page_quiz(self, parent):
        self.heading(parent, "Білімді тексер", "Бес қысқа сұрақ. Сайттағы мәліметті қаншалықты есте сақтағаныңды біл.")
        self.q_box = tk.Frame(parent, bg=self.c["surface"], padx=36, pady=30)
        self.q_box.pack(fill="x", padx=42, pady=(0, 36))
        self.q_i, self.q_score = 0, 0
        self._q_show()

    def _q_clear(self):
        for w in self.q_box.winfo_children():
            w.destroy()

    def _q_show(self):
        self._q_clear()
        bg, fg, mu = self.c["surface"], self.c["text"], self.c["muted"]
        q, options, right = QUIZ[self.q_i]
        track = tk.Canvas(self.q_box, height=8, highlightthickness=0, bg=self.c["surface2"])
        track.pack(fill="x", pady=(0, 16))
        track.bind("<Configure>", lambda e: (track.delete("all"),
                   track.create_rectangle(0, 0, e.width * self.q_i / len(QUIZ), 8, fill=SKY, outline="")))
        tk.Label(self.q_box, text=f"Сұрақ {self.q_i + 1} / {len(QUIZ)}", bg=bg, fg=mu,
                 font=self.f(10), anchor="w").pack(fill="x")
        Wrap(self.q_box, text=q, bg=bg, fg=fg, font=self.f(18, True)).pack(fill="x", pady=(4, 16))

        opts = []
        nxt = make_button(self.q_box, "Келесі сұрақ" if self.q_i < len(QUIZ) - 1 else "Нәтижені көру",
                          self._q_next, GOLD, "#1b1400", hover="#ffd869", font=self.f(12, True))

        def pick(idx):
            for b in opts:
                b._cmd = None
                b.configure(cursor="arrow")
            if idx == right:
                self.q_score += 1
                restyle(opts[idx], "#1f6b46", "white")
            else:
                restyle(opts[idx], "#8a2f2f", "white")
                restyle(opts[right], "#1f6b46", "white")
            nxt.pack(anchor="w", pady=(18, 0))

        for i, text in enumerate(options):
            b = make_button(self.q_box, text, lambda i=i: pick(i), self.c["bg"], fg,
                            hover=self.c["surface2"], font=self.f(13), padx=18, pady=12)
            b.configure(anchor="w")
            b.pack(fill="x", pady=5)
            opts.append(b)

    def _q_next(self):
        self.q_i += 1
        if self.q_i < len(QUIZ):
            self._q_show()
            return
        self._q_clear()
        bg, fg, mu = self.c["surface"], self.c["text"], self.c["muted"]
        tk.Label(self.q_box, text=f"{self.q_score} / {len(QUIZ)}", bg=bg, fg=fg, font=self.f(54, True)).pack(anchor="w")
        msg = ("Тамаша! Барлық жауап дұрыс." if self.q_score == len(QUIZ)
               else "Жақсы нәтиже! Бөлімдерді қайта шолып көр." if self.q_score >= 3
               else "Бөлімдерді қайта оқып, тағы бір рет байқап көр.")
        tk.Label(self.q_box, text=msg, bg=bg, fg=mu, font=self.f(13)).pack(anchor="w", pady=(4, 18))
        make_button(self.q_box, "Қайта бастау", lambda: self.show("quiz"), GOLD, "#1b1400",
                    hover="#ffd869", font=self.f(12, True)).pack(anchor="w")


if __name__ == "__main__":
    App().mainloop()
